﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","fr",{title:"Sélecteur de couleur",options:"Option de couleur",highlight:"Surligner",selected:"Couleur sélectionnée",predefined:"Palettes de couleurs prédéfinies",config:"Collez ce texte dans votre fichier config.js"});