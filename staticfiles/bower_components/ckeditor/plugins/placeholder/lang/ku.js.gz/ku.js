﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","ku",{title:"خاسیەتی شوێن هەڵگر",toolbar:"درووستکردنی شوێن هەڵگر",name:"ناوی شوێنگر",invalidName:"شوێنگر نابێت بەتاڵ بێت یان هەریەکێک لەم نووسانەی خوارەوەی تێدابێت: [, ], \x3c, \x3e",pathName:"شوێنگر"});